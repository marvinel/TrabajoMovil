package com.example.recyclerview


import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recyclerview.data.User
import kotlinx.android.synthetic.main.fragment_main.view.*

/**
 * A simple [Fragment] subclass.
 */
class MainFragment : Fragment(), UserAdapter.onListInteraction, View.OnClickListener {

    lateinit var navController: NavController
    val users = mutableListOf<User>()
    private var adapter :UserAdapter? = null
    var count : Int = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_main, container, false)



        adapter = UserAdapter(users, this)

        view.List.layoutManager = LinearLayoutManager(context)
        view.List.adapter = adapter

        view.floatingActionButton.setOnClickListener{
            users.add(User("Persona " + count))
            count++;
            adapter!!.updateData();
        }

        return view
    }

    override fun onListItemInteraction(item: User?) {
        Log.d("KRecycleView", "onListItemInteraction"+item!!.nombre )
    }

    override fun onListButtonInteraction(item: User?) {
        users.remove(item)
        adapter!!.updateData();

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        view.findViewById<Button>(R.id.button_personal).setOnClickListener(this)
    }
    override fun onClick(v: View?) {
        when(v!!.id){

            R.id.button_personal ->{
                navController!!.navigate(R.id.action_mainFragment_to_personalFragment)
            }
        }

    }


}
